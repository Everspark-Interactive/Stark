<?php
/**
 * ======================================
 * HTWF - SMTP CONFIG FILE
 * ======================================
 *
 * From this file you can set SMTP informations.
 * To enable the SMTP on your contact form add the attribute data-engine="smtp" to the form object.
 * Documentation at html.framework-y.com/components/contact-form/
 */

$smtp_config = array(
    'host' => '',
    'username' => '',
    'password' => '',
    'port' => '465',
    'email_from' => ''
);
?>
