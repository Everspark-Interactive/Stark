<?php
// =============================================================================
// TEMPLATE NAME: Background slider
// -----------------------------------------------------------------------------
// Background slider template.
// Documentation: framework-y.com/templates/base/template-background-slider.html
// =============================================================================

if (defined("HC_PLUGIN_PATH")) {
    include_once(HC_PLUGIN_PATH . "/global-content.php");
}
get_header();
engin_the_content();
get_footer();
?>
